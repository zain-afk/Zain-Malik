



<?PHP include'components/header.php'; ?>
 
        <!-- End of Topbar -->
 
    <?php


    include("config.php");
 
    if(isset($_POST['but_upload'])){
       $maxsize = 5242880000;  
       $u_nam=$_GET["u_nam"];
       $title=$_POST["title"];
       $dic=$_POST["dic"];
        $name = $_FILES['file']['name'];
       $target_dir = "videos/";
       $target_file = $target_dir . $_FILES["file"]["name"];
       
       $vkey=md5($name);
  
       // Select file type
       $videoFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

       // Valid file extensions
       $extensions_arr = array("mp4","avi","3gp","mov","mpeg");

       // Check extension
       if( in_array($videoFileType,$extensions_arr) )
       {
 
          // Check file size
          if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
            echo "File too large. File must be less than 5MB.";
          }else{
            // Upload

            if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file )){

              // Insert record
 $query = "INSERT INTO video(u_nam,discription,titlle,vido_name,location,video_key,thmbnail)
  VALUES('$u_nam','$dic' ,'$title',' $name ',' $target_file ','$vkey',timestamp)";

              mysqli_query($con,$query);
              echo "Upload successfully.";
            }

          }

       }
       else{
          echo "Invalid file extension.";
       }
 
     } 
     ?>

<center>
                    <h3></h3>
                        <h1 class="h4 text-gray-900 mb-4" style="margin-right: 120px;">Upload Your Video</h1>

 
  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
               <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                  </div>

   <form method="post"  enctype="multipart/form-data">
  <input type="file" name="file"/>
 <hr>
   <br>
<br>
   
<div class="form-group"> 
<input type="Text"name="title"class="form-control form-control-user"style="width: 420px;" placeholder="Title">
  </div>
  <div class="form-group">
<input type="Text"name="dic"class="form-control form-control-user"style="width: 420px;"placeholder="Discription">
  <br>
<br>

  <Input type="submit" class="btn btn-primary pull-right" class="form-group" name="but_upload">

         </div> 
    </center>
 </form>
   </div>
       </div>
    </div>
  </div>
  </div>
  </div>
   </div>
     </div>
  </div>


 