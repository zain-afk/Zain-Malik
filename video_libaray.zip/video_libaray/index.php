  
  <?php 
  include'config.php';
 include 'components/header.php'; 


  ?>

  <center> 
 
    <!-- Favicon -->
   	 <h1  style="margin-top: 10px;">Your All Favriout Video Is Here.....!!</h1>


 




		


 <?php
$query="SELECT * FROM video";

$res=mysqli_query($con,$query);
while ($data=mysqli_fetch_array($res))
 {
  	$location=$data["location"];
 	$video_key=$data["video_key"];
 	$titlle=$data["titlle"];
  	$tm=$data["tm"];

   ?>
    <!--Body start -->
 
<br>
<br>


<?php  if(isset($_SESSION["u_nam"]))
{
$u_nam=$_SESSION["u_nam"];
?>
  <div class="card" style="width: 29rem;">
<a href="play.php?v_key=<?php echo $video_key;?>&&u_nam=<?php  echo $u_nam; ?>" style="color: black; text-decoration: none;">
<video width="380" height="240">
<source src="<?php echo $location;?>"type="video/mp4">
</video>
 
   <div class="card-body">
     <h5 class="card-title"><?php echo $titlle; ?></h5>
     </a>
    <p class="card-text"> </p>
   </div>
</div>
 	
<?php }
else
{
 
 ?>
  <div class="card" style="width: 29rem;">
<a href="play.php?v_key=<?php echo $video_key;?>" style="color: black; text-decoration: none;">
<video width="380" height="240">
<source src="<?php echo $location;?>"type="video/mp4">
</video>
 
   <div class="card-body">
     <h5 class="card-title"><?php echo $titlle; ?></h5>
     </a>
    <p class="card-text"> </p>
   </div>
</div>


 



<?php } ?>


<?php } ?>







 <!--Body END -->
 